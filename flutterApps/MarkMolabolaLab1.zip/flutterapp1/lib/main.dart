import 'package:flutter/material.dart';

void main() {
  runApp(const BusinessCardApp());
}

class BusinessCardApp extends StatelessWidget {
  const BusinessCardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Business Card',
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1A237E))),
      home: const BusinessCardScreen(),
    );
  }
}

class BusinessCardScreen extends StatelessWidget {
  const BusinessCardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A237E),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: const [
          ProfileSection(),
          ContactSection(),
        ],
      ),
    );
  }
}

class ProfileSection extends StatelessWidget {
  const ProfileSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipOval(
          child: Image.asset(
            'lib/asset/images/pic.jpg',
            width: 150,
            height: 150,
            fit: BoxFit.cover,
            semanticLabel: 'Profile photo of Mark Molabola',
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Mark Gabriel Molabola',
          style: TextStyle(
            fontSize: 36,
            color: Colors.white,
            fontWeight: FontWeight.w300,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Software Developer',
          style: TextStyle(
            fontSize: 16,
            color: Color(0xFF3DDC84),
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }
}

class ContactSection extends StatelessWidget {
  const ContactSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Divider(color: Color(0xFF3DDC84), thickness: 1, indent: 40, endIndent: 40),
        const SizedBox(height: 16),
        Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              ContactRow(icon: Icons.phone, semanticLabel: 'Phone number', text: '+1 (562) 000-0000'),
              ContactRow(icon: Icons.alternate_email, semanticLabel: 'Social media handle', text: '@MarkMolabola'),
              ContactRow(icon: Icons.email, semanticLabel: 'Email address', text: 'markgabrielmolabola19@gmail.com'),
            ],
          ),
        ),
      ],
    );
  }
}

class ContactRow extends StatelessWidget {
  final IconData icon;
  final String semanticLabel;
  final String text;

  const ContactRow({
    super.key,
    required this.icon,
    required this.semanticLabel,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: const Color(0xFF3DDC84), semanticLabel: semanticLabel),
          const SizedBox(width: 16),
          Text(
            text,
            style: const TextStyle(color: Colors.white, fontSize: 16),
          ),
        ],
      ),
    );
  }
}
